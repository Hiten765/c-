#include<stdio.h>
void main()

{
    int a,b,c,max,min;
    printf("Enter Three Number:");
    scanf("%d %d %d", &a,&b,&c);

     max = a;
    if (b > max) max = b;
    if (c > max) max = c;

    // Find smallest
    min = a;
    if (b < min) min = b;
    if (c < min) min = c;

    printf("Largest: %d, Smallest: %d\n", max, min);
}
