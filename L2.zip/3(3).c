#include<stdio.h>
void main()

{
    int i,n;
    i=0;
    do
    {
        i+=2;
        printf("%d\n", i);

    }
    while(i<n);
}

