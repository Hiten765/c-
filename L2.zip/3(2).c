#include<stdio.h>
void main()

{
    int i;
    i=1;
    do
    {
        i+=2;
        printf("%d\n", i);

    }
    while(i<20);
}
