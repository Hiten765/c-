#include<stdio.h>
void main()

{
    int a;
    printf("Enter Number:");
    scanf("%d", &a);

    if(a%7==0)
    {printf("Divisible By 7");}

    else
    {printf("Not Divisible By 7");}

}
