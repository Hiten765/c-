#include<stdio.h>
void main()

{
    int a,b;
    printf("Enter Two Numbers:");
    scanf("%d %d", &a,&b);

    if(a>b)
        printf("Largest: %d, Smallest: %d\n", a, b);
    else
        printf("Largest: %d, Smallest: %d\n", b, a);
}
