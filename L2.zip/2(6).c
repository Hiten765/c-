#include <stdio.h>

void main() {
    float m1, m2, m3, total, avg;

    printf("Enter marks of 3 subjects: ");
    scanf("%f %f %f", &m1, &m2, &m3);

    if (m1 < 35 || m2 < 35 || m3 < 35) {
        printf("Student failed (less than 35 in a subject)\n");
    } else {
        total = m1 + m2 + m3;
        avg = total / 3;

        printf("Total = %.2f, Average = %.2f\n", total, avg);

        if (avg >= 70)
            printf("Distinction\n");
        else if (avg >= 60)
            printf("First class\n");
        else if (avg >= 50)
            printf("Second class\n");
        else if (avg >= 35)
            printf("Third class\n");
        else
            printf("Fail\n");
    }
}
