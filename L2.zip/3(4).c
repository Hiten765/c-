#include<stdio.h>
void main()

{
    int i;
    i=0;
    do
    {
        i++;
        printf("%d\n", i);

    }
    while(i<n);
}
